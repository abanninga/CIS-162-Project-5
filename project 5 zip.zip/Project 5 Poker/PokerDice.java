import java.util.ArrayList;
/**
 * Write a description of class PokerDice here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class PokerDice
{
    private ArrayList<GVdie> dice;
    private int score;
    private int numRolls;
    private int numRounds;
    private int[] tally;
    private int bonusScore;

    public static final int FULL_HOUSE = 35;
    public static final int THREE_KIND = 25;
    public static final int FOUR_KIND = 40;
    public static final int SMALL_STRAIGHT = 30;
    public static final int LARGE_STRAIGHT = 45;
    public static final int FIVE_KIND = 50;
    public static final int BONUS = 35;

    /**
     * Constructor for PokerDice Class
     * 
     * Initializes instance variables, adds 5 dice to ArrayList,
     * and resets game to initial values.
     */
    public PokerDice(){
        dice = new ArrayList<GVdie>();

        GVdie d1 = new GVdie();
        GVdie d2 = new GVdie();
        GVdie d3 = new GVdie();
        GVdie d4 = new GVdie();
        GVdie d5 = new GVdie();

        dice.add(d1);
        dice.add(d2);
        dice.add(d3);
        dice.add(d4);
        dice.add(d5);

        tally = new int[7];
        resetGame();
    }

    /**
     * Returns the current score
     * 
     * @return Score of the game
     */
    public int getScore(){
        if(bonusScore > 62)
            score += BONUS;
        return score;
    }

    /**
     * Returns true if it's legal to roll, false otherwise
     * 
     * @return True/False (ok to roll)
     */
    public boolean okToRoll(){
        if(numRolls < 3)
            return true;
        else
            return false;
    }

    /**
     * Tells if game is over based on what round it is
     * 
     * @return T/F (if there are more rounds)

     */
    public boolean gameOver(){
        if(numRounds < 13)
            return false;
        else
            return true;
    }

    /**
     * Returns the ArrayList of GVdie
     * 
     * @return dice
     */
    public ArrayList<GVdie> getDice(){
        return dice;
    }

    /**
     * Tallies the values of the current dice roll
     */
    private void tallyDice(){
        // clears the array
        for(int i = 1; i < tally.length; i++)
            tally[i] = 0;

        // update tally for each Die
        for(GVdie d : dice)
            tally[d.getValue()]++;
    } 

    /**
     * Determines if set of dice contains a sequence of length numbers
     * entered as an input parameter
     * 
     * @return true if dice contains a sequence of length, false otherwise
     */
    private boolean hasStraight(int length){
        tallyDice();
        int count = 0;
        for(int i = 1; i < tally.length; i++){
            if(tally[i] > 0){
                count++;
            }
            else{
                if(count == length){
                    return true;
                }
                count = 0;
            }
        }
        if(count >= length){
            return true;
        }
        else
            return false;
    }

    /**
     * Checks if set of dice contains multiples of size count
     * 
     * @param The minimum multiple amount checking
     * @return True if a multiple of at least size count is present
     */
    private boolean hasMultiples(int count){
        tallyDice();
        for(int i = 1; i < tally.length; i++)
            if(tally[i] >= count)
                return true;
        return false;
    }

    /**
     * Checks if set of dice contain a pair (but not more than a pair)
     * of numbers
     * 
     * @return True if a strict pair is found
     */
    private boolean hasStrictPair(){
        tallyDice();
        for(int i = 0; i < tally.length; i++)
            if(tally[i] == 2)
                return true;
        return false;
    }

    /**
     * Prepares for the next round of the game
     * Increments round, sets rolls to zero, and sets dice to blank
     */
    private void nextRound(){
        numRounds++;
        numRolls = 0;
        for(int i = 0; i < dice.size(); i++)
            dice.get(i).setBlank();
    }

    /**
     * Resets the game
     * Updates all instance variables to initial conditions
     */
    public void resetGame(){
        for(int i = 0; i < dice.size(); i++){
            if(dice.get(i).isHeld()){
                System.out.println("Cannot reset while dice are held");
            }
            else{
                numRounds = 0;
                numRolls = 0;
                score = 0;
                bonusScore = 0;
                for(int j = 0; j < dice.size(); j++)
                    dice.get(j).setBlank();
            }
        }
    }

    /**
     * Increments number of rolls and rolls each die not
     * currently held
     */
    public void rollDice(){
        numRolls++;
        for(int i = 0; i < dice.size(); i++)
            if(!dice.get(i).isHeld())
                dice.get(i).roll();
    }

    /**
     * Updates score if dice include a 3 of a kind
     */
    public void checkThreeOfAKind(){
        if(hasMultiples(3))
            score = score + THREE_KIND;
        nextRound();
    }

    /**
     * Updates score if dice include a full house
     */
    public void checkFullHouse(){
        if(hasMultiples(3) && hasStrictPair() || hasMultiples(5)){
            score = score + FULL_HOUSE;
        }
        nextRound();
    }

    /**
     * Updates score if dice currently have a small straight
     */
    public void checkSmallStraight(){
        if(hasStraight(4))
            score = score + SMALL_STRAIGHT;
        nextRound();
    }

    /**
     * Updates score if dice currently have a large straight
     */
    public void checkLargeStraight(){
        if(hasStraight(5))
            score = score + LARGE_STRAIGHT;
        nextRound();
    }

    /**
     * Updates score if dice currently have four of a kind
     */
    public void checkFourOfAKind(){
        if(hasMultiples(4))
            score = score + FOUR_KIND;
        nextRound();
    }

    /**
     * Updates score if dice currently have five of a kind
     */
    public void checkFiveOfAKind(){
        if(hasMultiples(5))
            score = score + FIVE_KIND;
        nextRound();
    }

    /**
     * Updates score by adding all dice with the value of val
     * 
     * @param the number you are adding all instances of
     */
    public void checkSingles(int val){
        tallyDice();
        score = score + (tally[val] * val);
        bonusScore = bonusScore + (tally[val] * val);
        nextRound();
    }

    /**
     * Updates the score with the sum of all dice
     */
    public void checkChance(){
        int chanceScore= 0;
        for(GVdie d: dice){
            chanceScore = d.getValue();
            score = score + chanceScore;
        }
        nextRound();
    }

    /**
     * Returns bonus score
     * 
     * @return bonus score
     */
    public int getBonusScore(){
        return bonusScore;
    }

    /**
     * Allows player to select values for each die
     * 
     * @param an array of five values to set the dice at
     */
    public void setDice(int[] values){
        int i = 0;
        for(GVdie d: dice){
            while(d.getValue() != values[i]){
                d.roll();
            }
            i++;
        }
    }
}
