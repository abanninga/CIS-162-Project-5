import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.ArrayList;
/***************************************************************
 * GUI front end to a dice game called Chuck A Luck
 * 
 * @author Scott Grissom 
 * @version September 14, 2013
 ***************************************************************/
public class PokerGUI extends JFrame implements ActionListener{

    /** visual representation of the dice */
    PokerDice theGame;

    /** buttons and labels */
    JButton ones, twos, threes, fours, fives, sixes, smallStraight,
    largeStraight, fullHouse, threeOfAKind, fourOfAKind, fiveOfAKind,
    chance;
    JLabel bonus, score;

    /** roll button */
    JButton rollButton;

    /** menu items */
    JMenuBar menus;
    JMenu fileMenu;
    JMenuItem quitItem;
    JMenuItem newGameItem; 

    /****************************************************************
    Main method start the game
     ****************************************************************/    
    public static void main(String args[]){        
        PokerGUI gui = new PokerGUI();
        gui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        gui.setTitle("Poker Dice Game!");
        gui.pack();
        gui.setVisible(true);
    }

    /****************************************************************
    Create all elements and display within the GUI
     ****************************************************************/    
    public PokerGUI(){ 

        // create the game object as well as the GUI Frame   
        theGame = new PokerDice(); 

        // create the lay out
        setLayout(new GridBagLayout());
        GridBagConstraints position = new GridBagConstraints();
        setBackground(Color.lightGray);

        // position score label
        position = new GridBagConstraints();        
        score = new JLabel ();
        score.setText("Score: " + theGame.getScore()); 
        position.gridx = 3;
        position.gridy = 8;
        add(score, position); 
        
        // position bonus label
        position = new GridBagConstraints(); 
        position.insets.bottom = 10;
        bonus = new JLabel ();
        bonus.setText("Bonus: " + theGame.getBonusScore()); 
        position.gridx = 1;
        position.gridy = 7;
        add(bonus, position);

        // create the roll button and add to grid location
        rollButton = new JButton("Roll");
        position.gridx = 2;
        position.gridy = 8;
        rollButton.addActionListener(this);
        rollButton.setBackground(Color.WHITE);
        add(rollButton, position);
        
        // score buttons
        ones = new JButton("1s");
        position.gridx = 1;
        position.gridy = 1;
        ones.addActionListener(this);
        ones.setBackground(Color.RED);
        add(ones, position);
        
        twos = new JButton("2s");
        position.gridx = 1;
        position.gridy = 2;
        twos.addActionListener(this);
        twos.setBackground(Color.ORANGE);
        add(twos, position);
        
        threes = new JButton("3s");
        position.gridx = 1;
        position.gridy = 3;
        threes.addActionListener(this);
        threes.setBackground(Color.YELLOW);
        add(threes, position);
        
        fours = new JButton("4s");
        position.gridx = 1;
        position.gridy = 4;
        fours.addActionListener(this);
        fours.setBackground(Color.GREEN);
        add(fours, position);
        
        fives = new JButton("5s");
        position.gridx = 1;
        position.gridy = 5;
        fives.addActionListener(this);
        fives.setBackground(Color.CYAN);
        add(fives, position);
        
        sixes = new JButton("6s");
        position.gridx = 1;
        position.gridy = 6;
        sixes.addActionListener(this);
        sixes.setBackground(Color.BLUE);
        add(sixes, position);
        
        smallStraight = new JButton("Small Straight");
        position.gridx = 3;
        position.gridy = 1;
        smallStraight.addActionListener(this);
        smallStraight.setBackground(Color.RED);
        add(smallStraight, position);

        largeStraight = new JButton("Large Straight");
        position.gridx = 3;
        position.gridy = 2;
        largeStraight.addActionListener(this);
        largeStraight.setBackground(Color.ORANGE);
        add(largeStraight, position);
        
        fullHouse = new JButton("Full House");
        position.gridx = 3;
        position.gridy = 3;
        fullHouse.addActionListener(this);
        fullHouse.setBackground(Color.YELLOW);
        add(fullHouse, position);
        
        threeOfAKind = new JButton("3 of a Kind");
        position.gridx = 3;
        position.gridy = 4;
        threeOfAKind.addActionListener(this);
        threeOfAKind.setBackground(Color.GREEN);
        add(threeOfAKind, position);
        
        fourOfAKind = new JButton("4 of a Kind");
        position.gridx = 3;
        position.gridy = 5;
        fourOfAKind.addActionListener(this);
        fourOfAKind.setBackground(Color.CYAN);
        add(fourOfAKind, position);
        
        fiveOfAKind = new JButton("5 of a Kind");
        position.gridx = 3;
        position.gridy = 6;
        fiveOfAKind.addActionListener(this);
        fiveOfAKind.setBackground(Color.BLUE);
        add(fiveOfAKind, position);
        
        chance = new JButton("Chance");
        position.gridx = 3;
        position.gridy = 7;
        chance.addActionListener(this);
        chance.setBackground(Color.MAGENTA);
        add(chance, position);
        
        // set up File menu
        fileMenu = new JMenu("File");
        quitItem = new JMenuItem("Quit");
        newGameItem = new JMenuItem("New Game");
        fileMenu.add(newGameItem);
        fileMenu.add(quitItem);
        menus = new JMenuBar();
        setJMenuBar(menus);
        menus.add(fileMenu); 

        // register the two menu items with this action listener
        newGameItem.addActionListener(this);
        quitItem.addActionListener(this);
        
        // request ArrayList of dice from game and position them
        ArrayList <GVdie> theDice = theGame.getDice();
        int col = 0;
        for(int i = 0; i < theDice.size(); i++){
            position.gridx = col;
            position.gridy = 0;
            position.insets.right = 10;
            position.insets.bottom = 10;
            add(theDice.get(i), position);
            col++;
        }
    }

    /****************************************************************
     * Start a new game
     ****************************************************************/
    private void reset(){
        // reset the game
        theGame.resetGame();
        bonus.setText("Bonus: " + theGame.getBonusScore());
        score.setText("Score " + theGame.getScore());

        ones.setEnabled(true);
        twos.setEnabled(true);
        threes.setEnabled(true);
        fours.setEnabled(true);
        fives.setEnabled(true);
        sixes.setEnabled(true);
        smallStraight.setEnabled(true);
        largeStraight.setEnabled(true);
        fullHouse.setEnabled(true);
        threeOfAKind.setEnabled(true);
        fourOfAKind.setEnabled(true);
        fiveOfAKind.setEnabled(true);
        chance.setEnabled(true);
        rollButton.setEnabled(true);
    }

    /****************************************************************
    This method called when the roll button or a menu item
    is selected

    @param event - the JComponent just selected
     ****************************************************************/
    public void actionPerformed(ActionEvent event){

        // player selects menu to quit the game
        if (event.getSource() == quitItem)
            System.exit(1);

        // player selects menu item to start a new game    
        if (event.getSource() == newGameItem){
            reset();
        }

        // player clicks on Roll button   
        if (event.getSource() == rollButton){    
            theGame.rollDice();  
        }
        
        // player clicks on scoring buttons
        if (event.getSource() == ones){    
            theGame.checkSingles(1);
            score.setText("Score: " + theGame.getScore());
            bonus.setText("Bonus: " + theGame.getBonusScore());
            ones.setEnabled(false);
        }
        
        if (event.getSource() == twos){    
            theGame.checkSingles(2);
            score.setText("Score: " + theGame.getScore());
            bonus.setText("Bonus: " + theGame.getBonusScore());
            twos.setEnabled(false);
        }
        
        if (event.getSource() == threes){    
            theGame.checkSingles(3); 
            score.setText("Score: " + theGame.getScore());
            bonus.setText("Bonus: " + theGame.getBonusScore());
            threes.setEnabled(false);
        }
        
        if (event.getSource() == fours){    
            theGame.checkSingles(4);
            score.setText("Score: " + theGame.getScore());
            bonus.setText("Bonus: " + theGame.getBonusScore());
            fours.setEnabled(false);
        }
        
        if (event.getSource() == fives){    
            theGame.checkSingles(5);
            score.setText("Score: " + theGame.getScore());
            bonus.setText("Bonus: " + theGame.getBonusScore());
            fives.setEnabled(false);
        }
        
        if (event.getSource() == sixes){    
            theGame.checkSingles(6);
            score.setText("Score: " + theGame.getScore());
            bonus.setText("Bonus: " + theGame.getBonusScore());
            sixes.setEnabled(false);
        }

        if (event.getSource() == smallStraight){
            theGame.checkSmallStraight();
            score.setText("Score: " + theGame.getScore());
            bonus.setText("Bonus: " + theGame.getBonusScore());
            smallStraight.setEnabled(false);
        }
        
        if (event.getSource() == largeStraight){
            theGame.checkLargeStraight();
            score.setText("Score: " + theGame.getScore());
            bonus.setText("Bonus: " + theGame.getBonusScore());
            largeStraight.setEnabled(false);
        }
        
        if (event.getSource() == fullHouse){
            theGame.checkFullHouse();
            score.setText("Score: " + theGame.getScore());
            bonus.setText("Bonus: " + theGame.getBonusScore());
            fullHouse.setEnabled(false);
        }
        
        if (event.getSource() == threeOfAKind){
            theGame.checkThreeOfAKind();
            score.setText("Score: " + theGame.getScore());
            bonus.setText("Bonus: " + theGame.getBonusScore());
            threeOfAKind.setEnabled(false);
        }
        
        if (event.getSource() == fourOfAKind){
            theGame.checkFourOfAKind();
            score.setText("Score: " + theGame.getScore());
            bonus.setText("Bonus: " + theGame.getBonusScore());
            fourOfAKind.setEnabled(false);
        }
        
        if (event.getSource() == fiveOfAKind){
            theGame.checkFiveOfAKind();
            score.setText("Score: " + theGame.getScore());
            bonus.setText("Bonus: " + theGame.getBonusScore());
            fiveOfAKind.setEnabled(false);
        }
        
        if (event.getSource() == chance){
            theGame.checkChance();
            score.setText("Score: " + theGame.getScore());
            bonus.setText("Bonus: " + theGame.getBonusScore());
            chance.setEnabled(false);
        }
        
        if(theGame.okToRoll()){
            rollButton.setEnabled(true);
        }
        else{
            rollButton.setEnabled(false);
        }
        
        if(theGame.gameOver()){
            JOptionPane.showMessageDialog(null, "You win!");
            rollButton.setEnabled(false);
        }
    }
}