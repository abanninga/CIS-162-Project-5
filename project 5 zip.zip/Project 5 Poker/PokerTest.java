import java.util.ArrayList;
/**
 * Write a description of class PokerTest here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class PokerTest
{
    public static void main(String [] args){

        int before;
        PokerDice game = new PokerDice();

        System.out.println("\nTesting begins...");

        // check for valid small straight
        before = game.getScore();
        game.setDice(new int[] {2,4,5,3,3});
        game.checkSmallStraight();
        if(before + PokerDice.SMALL_STRAIGHT != game.getScore()){
            System.out.println("FAIL: small straight not scored");
        }

        // check for bad small straight
        before = game.getScore();
        game.setDice(new int[] {2,4,4,3,3});
        game.checkSmallStraight();
        if(before != game.getScore()){
            System.out.println("FAIL: small straight scored but not valid");
        }
        
        // check large straight
        before = game.getScore();
        game.setDice(new int[] {2,4,5,3,1});
        game.checkLargeStraight();
        if(before + PokerDice.LARGE_STRAIGHT != game.getScore()){
            System.out.println("FAIL: large straight not scored");
        }

        //check for 3 of a kind
        before = game.getScore();
        game.setDice(new int[] {3,3,3,1,4});
        game.checkThreeOfAKind();
        if(before + PokerDice.THREE_KIND != game.getScore()){
            System.out.println("FAIL: three of a kind not scored");
        }
        
        // check for full house
        before = game.getScore();
        game.setDice(new int[] {2,2,4,4,4});
        game.checkFullHouse();
        if(before + PokerDice.FULL_HOUSE != game.getScore()){
            System.out.println("FAIL: full house not scored");
        }
        
        // check for 4 of a kind
        before = game.getScore();
        game.setDice(new int[] {1,1,2,1,1});
        game.checkFourOfAKind();
        if(before + PokerDice.FOUR_KIND != game.getScore()){
            System.out.println("FAIL: four of a kind not scored");
        }
        
        // check for five of a kind
        before = game.getScore();
        game.setDice(new int[] {1,1,1,1,1});
        game.checkFiveOfAKind();
        if(before + PokerDice.FIVE_KIND != game.getScore()){
            System.out.println("FAIL: five of a kind not scored");
        }
        
        // check singles & bonus score
        before = game.getScore();        
        int bonusBefore = game.getBonusScore();
        game.setDice(new int[] {1,1,2,1,1});
        game.checkSingles(1);
        if(before + 4 != game.getScore()){
            System.out.println("FAIL: singles not scored");
        }
        if(bonusBefore + 4 != game.getBonusScore()){
            System.out.println("FAIL: bonus score not added");
        }
        
        // check chance
        before = game.getScore();
        game.setDice(new int[] {1,1,2,1,1});
        game.checkChance();
        if(before + 6 != game.getScore()){
            System.out.println("FAIL: chance not scored");
        }
        
        
        System.out.println("Testing completed.");
    }
}
